﻿namespace EntradasTeatro
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonAniadir1 = new System.Windows.Forms.Button();
            this.groupBoxEntrada1 = new System.Windows.Forms.GroupBox();
            this.labelEdad = new System.Windows.Forms.Label();
            this.radioButton1E1 = new System.Windows.Forms.RadioButton();
            this.radioButton2E1 = new System.Windows.Forms.RadioButton();
            this.radioButton3E1 = new System.Windows.Forms.RadioButton();
            this.radioButton4E1 = new System.Windows.Forms.RadioButton();
            this.radioButton5E1 = new System.Windows.Forms.RadioButton();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBoxEntrada2 = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.radioButton5E2 = new System.Windows.Forms.RadioButton();
            this.radioButton4E2 = new System.Windows.Forms.RadioButton();
            this.radioButton3E2 = new System.Windows.Forms.RadioButton();
            this.radioButton2E2 = new System.Windows.Forms.RadioButton();
            this.radioButton1E2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxEntrada3 = new System.Windows.Forms.GroupBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.radioButton5E3 = new System.Windows.Forms.RadioButton();
            this.radioButton4E3 = new System.Windows.Forms.RadioButton();
            this.radioButton3E3 = new System.Windows.Forms.RadioButton();
            this.radioButton2E3 = new System.Windows.Forms.RadioButton();
            this.radioButton1E3 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxEntrada4 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.radioButton5E4 = new System.Windows.Forms.RadioButton();
            this.radioButton4E4 = new System.Windows.Forms.RadioButton();
            this.radioButton3E4 = new System.Windows.Forms.RadioButton();
            this.radioButton2E4 = new System.Windows.Forms.RadioButton();
            this.radioButton1E4 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxEntrada5 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.radioButton5E5 = new System.Windows.Forms.RadioButton();
            this.radioButton4E5 = new System.Windows.Forms.RadioButton();
            this.radioButton3E5 = new System.Windows.Forms.RadioButton();
            this.radioButton2E5 = new System.Windows.Forms.RadioButton();
            this.radioButton1E5 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonCalcular1 = new System.Windows.Forms.Button();
            this.buttonCalcular2 = new System.Windows.Forms.Button();
            this.buttonAniadir2 = new System.Windows.Forms.Button();
            this.buttonCalcular3 = new System.Windows.Forms.Button();
            this.buttonAniadir3 = new System.Windows.Forms.Button();
            this.buttonCalcular4 = new System.Windows.Forms.Button();
            this.buttonAniadir4 = new System.Windows.Forms.Button();
            this.buttonCalcular5 = new System.Windows.Forms.Button();
            this.panelResumenCompra = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.labelEntrada1 = new System.Windows.Forms.Label();
            this.labelEntrada2 = new System.Windows.Forms.Label();
            this.labelEntrada3 = new System.Windows.Forms.Label();
            this.labelEntrada4 = new System.Windows.Forms.Label();
            this.labelEntrada5 = new System.Windows.Forms.Label();
            this.labelDescuento1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.labelDescuento2 = new System.Windows.Forms.Label();
            this.labelDescuento3 = new System.Windows.Forms.Label();
            this.labelDescuento4 = new System.Windows.Forms.Label();
            this.labelDescuento5 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labelPrecio5 = new System.Windows.Forms.Label();
            this.labelPrecio4 = new System.Windows.Forms.Label();
            this.labelPrecio3 = new System.Windows.Forms.Label();
            this.labelPrecio2 = new System.Windows.Forms.Label();
            this.labelPrecio1 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.groupBoxEntrada1.SuspendLayout();
            this.groupBoxEntrada2.SuspendLayout();
            this.groupBoxEntrada3.SuspendLayout();
            this.groupBoxEntrada4.SuspendLayout();
            this.groupBoxEntrada5.SuspendLayout();
            this.panelResumenCompra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonAniadir1
            // 
            this.buttonAniadir1.Location = new System.Drawing.Point(318, 136);
            this.buttonAniadir1.Name = "buttonAniadir1";
            this.buttonAniadir1.Size = new System.Drawing.Size(182, 39);
            this.buttonAniadir1.TabIndex = 7;
            this.buttonAniadir1.Text = "+ Añadir entrada";
            this.buttonAniadir1.UseVisualStyleBackColor = true;
            this.buttonAniadir1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBoxEntrada1
            // 
            this.groupBoxEntrada1.Controls.Add(this.buttonCalcular1);
            this.groupBoxEntrada1.Controls.Add(this.checkBox1);
            this.groupBoxEntrada1.Controls.Add(this.radioButton5E1);
            this.groupBoxEntrada1.Controls.Add(this.radioButton4E1);
            this.groupBoxEntrada1.Controls.Add(this.radioButton3E1);
            this.groupBoxEntrada1.Controls.Add(this.buttonAniadir1);
            this.groupBoxEntrada1.Controls.Add(this.radioButton2E1);
            this.groupBoxEntrada1.Controls.Add(this.radioButton1E1);
            this.groupBoxEntrada1.Controls.Add(this.labelEdad);
            this.groupBoxEntrada1.Controls.Add(this.pictureBox3);
            this.groupBoxEntrada1.Location = new System.Drawing.Point(29, 51);
            this.groupBoxEntrada1.Name = "groupBoxEntrada1";
            this.groupBoxEntrada1.Size = new System.Drawing.Size(500, 211);
            this.groupBoxEntrada1.TabIndex = 1;
            this.groupBoxEntrada1.TabStop = false;
            this.groupBoxEntrada1.Text = "Entrada 1";
            // 
            // labelEdad
            // 
            this.labelEdad.AutoSize = true;
            this.labelEdad.Location = new System.Drawing.Point(29, 45);
            this.labelEdad.Name = "labelEdad";
            this.labelEdad.Size = new System.Drawing.Size(284, 29);
            this.labelEdad.TabIndex = 0;
            this.labelEdad.Text = "Seleccione el rango de edad:";
            // 
            // radioButton1E1
            // 
            this.radioButton1E1.AutoSize = true;
            this.radioButton1E1.Location = new System.Drawing.Point(34, 78);
            this.radioButton1E1.Name = "radioButton1E1";
            this.radioButton1E1.Size = new System.Drawing.Size(133, 33);
            this.radioButton1E1.TabIndex = 1;
            this.radioButton1E1.Text = "5 - 14 años";
            this.radioButton1E1.UseVisualStyleBackColor = true;
            // 
            // radioButton2E1
            // 
            this.radioButton2E1.AutoSize = true;
            this.radioButton2E1.Location = new System.Drawing.Point(182, 78);
            this.radioButton2E1.Name = "radioButton2E1";
            this.radioButton2E1.Size = new System.Drawing.Size(145, 33);
            this.radioButton2E1.TabIndex = 2;
            this.radioButton2E1.Text = "15 - 19 años";
            this.radioButton2E1.UseVisualStyleBackColor = true;
            // 
            // radioButton3E1
            // 
            this.radioButton3E1.AutoSize = true;
            this.radioButton3E1.Checked = true;
            this.radioButton3E1.Location = new System.Drawing.Point(333, 78);
            this.radioButton3E1.Name = "radioButton3E1";
            this.radioButton3E1.Size = new System.Drawing.Size(145, 33);
            this.radioButton3E1.TabIndex = 3;
            this.radioButton3E1.TabStop = true;
            this.radioButton3E1.Text = "20 - 45 años";
            this.radioButton3E1.UseVisualStyleBackColor = true;
            // 
            // radioButton4E1
            // 
            this.radioButton4E1.AutoSize = true;
            this.radioButton4E1.Location = new System.Drawing.Point(34, 117);
            this.radioButton4E1.Name = "radioButton4E1";
            this.radioButton4E1.Size = new System.Drawing.Size(145, 33);
            this.radioButton4E1.TabIndex = 4;
            this.radioButton4E1.Text = "46 - 65 años";
            this.radioButton4E1.UseVisualStyleBackColor = true;
            // 
            // radioButton5E1
            // 
            this.radioButton5E1.AutoSize = true;
            this.radioButton5E1.Location = new System.Drawing.Point(182, 117);
            this.radioButton5E1.Name = "radioButton5E1";
            this.radioButton5E1.Size = new System.Drawing.Size(125, 33);
            this.radioButton5E1.TabIndex = 5;
            this.radioButton5E1.Text = "> 65 años";
            this.radioButton5E1.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(34, 172);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(263, 33);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Descuento discapacidad";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBoxEntrada2
            // 
            this.groupBoxEntrada2.Controls.Add(this.buttonCalcular2);
            this.groupBoxEntrada2.Controls.Add(this.checkBox2);
            this.groupBoxEntrada2.Controls.Add(this.buttonAniadir2);
            this.groupBoxEntrada2.Controls.Add(this.radioButton5E2);
            this.groupBoxEntrada2.Controls.Add(this.radioButton4E2);
            this.groupBoxEntrada2.Controls.Add(this.radioButton3E2);
            this.groupBoxEntrada2.Controls.Add(this.radioButton2E2);
            this.groupBoxEntrada2.Controls.Add(this.radioButton1E2);
            this.groupBoxEntrada2.Controls.Add(this.label1);
            this.groupBoxEntrada2.Controls.Add(this.pictureBox4);
            this.groupBoxEntrada2.Location = new System.Drawing.Point(29, 262);
            this.groupBoxEntrada2.Name = "groupBoxEntrada2";
            this.groupBoxEntrada2.Size = new System.Drawing.Size(500, 211);
            this.groupBoxEntrada2.TabIndex = 3;
            this.groupBoxEntrada2.TabStop = false;
            this.groupBoxEntrada2.Text = "Entrada 2";
            this.groupBoxEntrada2.Visible = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(34, 172);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(263, 33);
            this.checkBox2.TabIndex = 6;
            this.checkBox2.Text = "Descuento discapacidad";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // radioButton5E2
            // 
            this.radioButton5E2.AutoSize = true;
            this.radioButton5E2.Location = new System.Drawing.Point(182, 117);
            this.radioButton5E2.Name = "radioButton5E2";
            this.radioButton5E2.Size = new System.Drawing.Size(125, 33);
            this.radioButton5E2.TabIndex = 5;
            this.radioButton5E2.Text = "> 65 años";
            this.radioButton5E2.UseVisualStyleBackColor = true;
            // 
            // radioButton4E2
            // 
            this.radioButton4E2.AutoSize = true;
            this.radioButton4E2.Location = new System.Drawing.Point(34, 117);
            this.radioButton4E2.Name = "radioButton4E2";
            this.radioButton4E2.Size = new System.Drawing.Size(145, 33);
            this.radioButton4E2.TabIndex = 4;
            this.radioButton4E2.Text = "46 - 65 años";
            this.radioButton4E2.UseVisualStyleBackColor = true;
            // 
            // radioButton3E2
            // 
            this.radioButton3E2.AutoSize = true;
            this.radioButton3E2.Checked = true;
            this.radioButton3E2.Location = new System.Drawing.Point(333, 78);
            this.radioButton3E2.Name = "radioButton3E2";
            this.radioButton3E2.Size = new System.Drawing.Size(145, 33);
            this.radioButton3E2.TabIndex = 3;
            this.radioButton3E2.TabStop = true;
            this.radioButton3E2.Text = "20 - 45 años";
            this.radioButton3E2.UseVisualStyleBackColor = true;
            // 
            // radioButton2E2
            // 
            this.radioButton2E2.AutoSize = true;
            this.radioButton2E2.Location = new System.Drawing.Point(182, 78);
            this.radioButton2E2.Name = "radioButton2E2";
            this.radioButton2E2.Size = new System.Drawing.Size(145, 33);
            this.radioButton2E2.TabIndex = 2;
            this.radioButton2E2.Text = "15 - 19 años";
            this.radioButton2E2.UseVisualStyleBackColor = true;
            // 
            // radioButton1E2
            // 
            this.radioButton1E2.AutoSize = true;
            this.radioButton1E2.Location = new System.Drawing.Point(34, 78);
            this.radioButton1E2.Name = "radioButton1E2";
            this.radioButton1E2.Size = new System.Drawing.Size(133, 33);
            this.radioButton1E2.TabIndex = 1;
            this.radioButton1E2.Text = "5 - 14 años";
            this.radioButton1E2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(284, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seleccione el rango de edad:";
            // 
            // groupBoxEntrada3
            // 
            this.groupBoxEntrada3.Controls.Add(this.buttonCalcular3);
            this.groupBoxEntrada3.Controls.Add(this.checkBox3);
            this.groupBoxEntrada3.Controls.Add(this.buttonAniadir3);
            this.groupBoxEntrada3.Controls.Add(this.radioButton5E3);
            this.groupBoxEntrada3.Controls.Add(this.radioButton4E3);
            this.groupBoxEntrada3.Controls.Add(this.radioButton3E3);
            this.groupBoxEntrada3.Controls.Add(this.radioButton2E3);
            this.groupBoxEntrada3.Controls.Add(this.radioButton1E3);
            this.groupBoxEntrada3.Controls.Add(this.label2);
            this.groupBoxEntrada3.Controls.Add(this.pictureBox5);
            this.groupBoxEntrada3.Location = new System.Drawing.Point(29, 473);
            this.groupBoxEntrada3.Name = "groupBoxEntrada3";
            this.groupBoxEntrada3.Size = new System.Drawing.Size(500, 211);
            this.groupBoxEntrada3.TabIndex = 8;
            this.groupBoxEntrada3.TabStop = false;
            this.groupBoxEntrada3.Text = "Entrada 3";
            this.groupBoxEntrada3.Visible = false;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(34, 172);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(263, 33);
            this.checkBox3.TabIndex = 6;
            this.checkBox3.Text = "Descuento discapacidad";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // radioButton5E3
            // 
            this.radioButton5E3.AutoSize = true;
            this.radioButton5E3.Location = new System.Drawing.Point(182, 117);
            this.radioButton5E3.Name = "radioButton5E3";
            this.radioButton5E3.Size = new System.Drawing.Size(125, 33);
            this.radioButton5E3.TabIndex = 5;
            this.radioButton5E3.Text = "> 65 años";
            this.radioButton5E3.UseVisualStyleBackColor = true;
            // 
            // radioButton4E3
            // 
            this.radioButton4E3.AutoSize = true;
            this.radioButton4E3.Location = new System.Drawing.Point(34, 117);
            this.radioButton4E3.Name = "radioButton4E3";
            this.radioButton4E3.Size = new System.Drawing.Size(145, 33);
            this.radioButton4E3.TabIndex = 4;
            this.radioButton4E3.Text = "46 - 65 años";
            this.radioButton4E3.UseVisualStyleBackColor = true;
            // 
            // radioButton3E3
            // 
            this.radioButton3E3.AutoSize = true;
            this.radioButton3E3.Checked = true;
            this.radioButton3E3.Location = new System.Drawing.Point(333, 78);
            this.radioButton3E3.Name = "radioButton3E3";
            this.radioButton3E3.Size = new System.Drawing.Size(145, 33);
            this.radioButton3E3.TabIndex = 3;
            this.radioButton3E3.TabStop = true;
            this.radioButton3E3.Text = "20 - 45 años";
            this.radioButton3E3.UseVisualStyleBackColor = true;
            // 
            // radioButton2E3
            // 
            this.radioButton2E3.AutoSize = true;
            this.radioButton2E3.Location = new System.Drawing.Point(182, 78);
            this.radioButton2E3.Name = "radioButton2E3";
            this.radioButton2E3.Size = new System.Drawing.Size(145, 33);
            this.radioButton2E3.TabIndex = 2;
            this.radioButton2E3.Text = "15 - 19 años";
            this.radioButton2E3.UseVisualStyleBackColor = true;
            // 
            // radioButton1E3
            // 
            this.radioButton1E3.AutoSize = true;
            this.radioButton1E3.Location = new System.Drawing.Point(34, 78);
            this.radioButton1E3.Name = "radioButton1E3";
            this.radioButton1E3.Size = new System.Drawing.Size(133, 33);
            this.radioButton1E3.TabIndex = 1;
            this.radioButton1E3.Text = "5 - 14 años";
            this.radioButton1E3.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(284, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Seleccione el rango de edad:";
            // 
            // groupBoxEntrada4
            // 
            this.groupBoxEntrada4.Controls.Add(this.buttonCalcular4);
            this.groupBoxEntrada4.Controls.Add(this.checkBox4);
            this.groupBoxEntrada4.Controls.Add(this.buttonAniadir4);
            this.groupBoxEntrada4.Controls.Add(this.radioButton5E4);
            this.groupBoxEntrada4.Controls.Add(this.radioButton4E4);
            this.groupBoxEntrada4.Controls.Add(this.radioButton3E4);
            this.groupBoxEntrada4.Controls.Add(this.radioButton2E4);
            this.groupBoxEntrada4.Controls.Add(this.radioButton1E4);
            this.groupBoxEntrada4.Controls.Add(this.label4);
            this.groupBoxEntrada4.Controls.Add(this.pictureBox6);
            this.groupBoxEntrada4.Location = new System.Drawing.Point(567, 51);
            this.groupBoxEntrada4.Name = "groupBoxEntrada4";
            this.groupBoxEntrada4.Size = new System.Drawing.Size(500, 211);
            this.groupBoxEntrada4.TabIndex = 12;
            this.groupBoxEntrada4.TabStop = false;
            this.groupBoxEntrada4.Text = "Entrada 4";
            this.groupBoxEntrada4.Visible = false;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(34, 172);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(263, 33);
            this.checkBox4.TabIndex = 6;
            this.checkBox4.Text = "Descuento discapacidad";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // radioButton5E4
            // 
            this.radioButton5E4.AutoSize = true;
            this.radioButton5E4.Location = new System.Drawing.Point(182, 117);
            this.radioButton5E4.Name = "radioButton5E4";
            this.radioButton5E4.Size = new System.Drawing.Size(125, 33);
            this.radioButton5E4.TabIndex = 5;
            this.radioButton5E4.Text = "> 65 años";
            this.radioButton5E4.UseVisualStyleBackColor = true;
            // 
            // radioButton4E4
            // 
            this.radioButton4E4.AutoSize = true;
            this.radioButton4E4.Location = new System.Drawing.Point(34, 117);
            this.radioButton4E4.Name = "radioButton4E4";
            this.radioButton4E4.Size = new System.Drawing.Size(145, 33);
            this.radioButton4E4.TabIndex = 4;
            this.radioButton4E4.Text = "46 - 65 años";
            this.radioButton4E4.UseVisualStyleBackColor = true;
            // 
            // radioButton3E4
            // 
            this.radioButton3E4.AutoSize = true;
            this.radioButton3E4.Checked = true;
            this.radioButton3E4.Location = new System.Drawing.Point(333, 78);
            this.radioButton3E4.Name = "radioButton3E4";
            this.radioButton3E4.Size = new System.Drawing.Size(145, 33);
            this.radioButton3E4.TabIndex = 3;
            this.radioButton3E4.TabStop = true;
            this.radioButton3E4.Text = "20 - 45 años";
            this.radioButton3E4.UseVisualStyleBackColor = true;
            // 
            // radioButton2E4
            // 
            this.radioButton2E4.AutoSize = true;
            this.radioButton2E4.Location = new System.Drawing.Point(182, 78);
            this.radioButton2E4.Name = "radioButton2E4";
            this.radioButton2E4.Size = new System.Drawing.Size(145, 33);
            this.radioButton2E4.TabIndex = 2;
            this.radioButton2E4.Text = "15 - 19 años";
            this.radioButton2E4.UseVisualStyleBackColor = true;
            // 
            // radioButton1E4
            // 
            this.radioButton1E4.AutoSize = true;
            this.radioButton1E4.Location = new System.Drawing.Point(34, 78);
            this.radioButton1E4.Name = "radioButton1E4";
            this.radioButton1E4.Size = new System.Drawing.Size(133, 33);
            this.radioButton1E4.TabIndex = 1;
            this.radioButton1E4.Text = "5 - 14 años";
            this.radioButton1E4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(284, 29);
            this.label4.TabIndex = 0;
            this.label4.Text = "Seleccione el rango de edad:";
            // 
            // groupBoxEntrada5
            // 
            this.groupBoxEntrada5.Controls.Add(this.buttonCalcular5);
            this.groupBoxEntrada5.Controls.Add(this.checkBox5);
            this.groupBoxEntrada5.Controls.Add(this.radioButton5E5);
            this.groupBoxEntrada5.Controls.Add(this.radioButton4E5);
            this.groupBoxEntrada5.Controls.Add(this.radioButton3E5);
            this.groupBoxEntrada5.Controls.Add(this.radioButton2E5);
            this.groupBoxEntrada5.Controls.Add(this.radioButton1E5);
            this.groupBoxEntrada5.Controls.Add(this.label5);
            this.groupBoxEntrada5.Controls.Add(this.pictureBox7);
            this.groupBoxEntrada5.Location = new System.Drawing.Point(567, 262);
            this.groupBoxEntrada5.Name = "groupBoxEntrada5";
            this.groupBoxEntrada5.Size = new System.Drawing.Size(500, 211);
            this.groupBoxEntrada5.TabIndex = 16;
            this.groupBoxEntrada5.TabStop = false;
            this.groupBoxEntrada5.Text = "Entrada 5";
            this.groupBoxEntrada5.Visible = false;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(34, 172);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(263, 33);
            this.checkBox5.TabIndex = 6;
            this.checkBox5.Text = "Descuento discapacidad";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // radioButton5E5
            // 
            this.radioButton5E5.AutoSize = true;
            this.radioButton5E5.Location = new System.Drawing.Point(182, 117);
            this.radioButton5E5.Name = "radioButton5E5";
            this.radioButton5E5.Size = new System.Drawing.Size(125, 33);
            this.radioButton5E5.TabIndex = 5;
            this.radioButton5E5.Text = "> 65 años";
            this.radioButton5E5.UseVisualStyleBackColor = true;
            // 
            // radioButton4E5
            // 
            this.radioButton4E5.AutoSize = true;
            this.radioButton4E5.Location = new System.Drawing.Point(34, 117);
            this.radioButton4E5.Name = "radioButton4E5";
            this.radioButton4E5.Size = new System.Drawing.Size(145, 33);
            this.radioButton4E5.TabIndex = 4;
            this.radioButton4E5.Text = "46 - 65 años";
            this.radioButton4E5.UseVisualStyleBackColor = true;
            // 
            // radioButton3E5
            // 
            this.radioButton3E5.AutoSize = true;
            this.radioButton3E5.Checked = true;
            this.radioButton3E5.Location = new System.Drawing.Point(333, 78);
            this.radioButton3E5.Name = "radioButton3E5";
            this.radioButton3E5.Size = new System.Drawing.Size(145, 33);
            this.radioButton3E5.TabIndex = 3;
            this.radioButton3E5.TabStop = true;
            this.radioButton3E5.Text = "20 - 45 años";
            this.radioButton3E5.UseVisualStyleBackColor = true;
            // 
            // radioButton2E5
            // 
            this.radioButton2E5.AutoSize = true;
            this.radioButton2E5.Location = new System.Drawing.Point(182, 78);
            this.radioButton2E5.Name = "radioButton2E5";
            this.radioButton2E5.Size = new System.Drawing.Size(145, 33);
            this.radioButton2E5.TabIndex = 2;
            this.radioButton2E5.Text = "15 - 19 años";
            this.radioButton2E5.UseVisualStyleBackColor = true;
            // 
            // radioButton1E5
            // 
            this.radioButton1E5.AutoSize = true;
            this.radioButton1E5.Location = new System.Drawing.Point(34, 78);
            this.radioButton1E5.Name = "radioButton1E5";
            this.radioButton1E5.Size = new System.Drawing.Size(133, 33);
            this.radioButton1E5.TabIndex = 1;
            this.radioButton1E5.Text = "5 - 14 años";
            this.radioButton1E5.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(284, 29);
            this.label5.TabIndex = 0;
            this.label5.Text = "Seleccione el rango de edad:";
            // 
            // buttonCalcular1
            // 
            this.buttonCalcular1.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonCalcular1.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCalcular1.Location = new System.Drawing.Point(318, 172);
            this.buttonCalcular1.Name = "buttonCalcular1";
            this.buttonCalcular1.Size = new System.Drawing.Size(182, 39);
            this.buttonCalcular1.TabIndex = 8;
            this.buttonCalcular1.Text = "Calcular precio";
            this.buttonCalcular1.UseVisualStyleBackColor = false;
            this.buttonCalcular1.Click += new System.EventHandler(this.buttonCalcular1_Click);
            // 
            // buttonCalcular2
            // 
            this.buttonCalcular2.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonCalcular2.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCalcular2.Location = new System.Drawing.Point(318, 171);
            this.buttonCalcular2.Name = "buttonCalcular2";
            this.buttonCalcular2.Size = new System.Drawing.Size(182, 39);
            this.buttonCalcular2.TabIndex = 8;
            this.buttonCalcular2.Text = "Calcular precio";
            this.buttonCalcular2.UseVisualStyleBackColor = false;
            this.buttonCalcular2.Visible = false;
            this.buttonCalcular2.Click += new System.EventHandler(this.buttonCalcular2_Click);
            // 
            // buttonAniadir2
            // 
            this.buttonAniadir2.Location = new System.Drawing.Point(318, 135);
            this.buttonAniadir2.Name = "buttonAniadir2";
            this.buttonAniadir2.Size = new System.Drawing.Size(182, 39);
            this.buttonAniadir2.TabIndex = 7;
            this.buttonAniadir2.Text = "+ Añadir entrada";
            this.buttonAniadir2.UseVisualStyleBackColor = true;
            this.buttonAniadir2.Visible = false;
            this.buttonAniadir2.Click += new System.EventHandler(this.buttonAniadir2_Click);
            // 
            // buttonCalcular3
            // 
            this.buttonCalcular3.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonCalcular3.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCalcular3.Location = new System.Drawing.Point(318, 171);
            this.buttonCalcular3.Name = "buttonCalcular3";
            this.buttonCalcular3.Size = new System.Drawing.Size(182, 39);
            this.buttonCalcular3.TabIndex = 8;
            this.buttonCalcular3.Text = "Calcular precio";
            this.buttonCalcular3.UseVisualStyleBackColor = false;
            this.buttonCalcular3.Visible = false;
            this.buttonCalcular3.Click += new System.EventHandler(this.buttonCalcular3_Click);
            // 
            // buttonAniadir3
            // 
            this.buttonAniadir3.Location = new System.Drawing.Point(318, 135);
            this.buttonAniadir3.Name = "buttonAniadir3";
            this.buttonAniadir3.Size = new System.Drawing.Size(182, 39);
            this.buttonAniadir3.TabIndex = 7;
            this.buttonAniadir3.Text = "+ Añadir entrada";
            this.buttonAniadir3.UseVisualStyleBackColor = true;
            this.buttonAniadir3.Visible = false;
            this.buttonAniadir3.Click += new System.EventHandler(this.buttonAniadir3_Click);
            // 
            // buttonCalcular4
            // 
            this.buttonCalcular4.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonCalcular4.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCalcular4.Location = new System.Drawing.Point(318, 172);
            this.buttonCalcular4.Name = "buttonCalcular4";
            this.buttonCalcular4.Size = new System.Drawing.Size(182, 39);
            this.buttonCalcular4.TabIndex = 8;
            this.buttonCalcular4.Text = "Calcular precio";
            this.buttonCalcular4.UseVisualStyleBackColor = false;
            this.buttonCalcular4.Visible = false;
            this.buttonCalcular4.Click += new System.EventHandler(this.buttonCalcular4_Click);
            // 
            // buttonAniadir4
            // 
            this.buttonAniadir4.Location = new System.Drawing.Point(318, 136);
            this.buttonAniadir4.Name = "buttonAniadir4";
            this.buttonAniadir4.Size = new System.Drawing.Size(182, 39);
            this.buttonAniadir4.TabIndex = 7;
            this.buttonAniadir4.Text = "+ Añadir entrada";
            this.buttonAniadir4.UseVisualStyleBackColor = true;
            this.buttonAniadir4.Visible = false;
            this.buttonAniadir4.Click += new System.EventHandler(this.buttonAniadir4_Click);
            // 
            // buttonCalcular5
            // 
            this.buttonCalcular5.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonCalcular5.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCalcular5.Location = new System.Drawing.Point(318, 171);
            this.buttonCalcular5.Name = "buttonCalcular5";
            this.buttonCalcular5.Size = new System.Drawing.Size(182, 39);
            this.buttonCalcular5.TabIndex = 7;
            this.buttonCalcular5.Text = "Calcular precio";
            this.buttonCalcular5.UseVisualStyleBackColor = false;
            this.buttonCalcular5.Visible = false;
            this.buttonCalcular5.Click += new System.EventHandler(this.buttonCalcular5_Click);
            // 
            // panelResumenCompra
            // 
            this.panelResumenCompra.Controls.Add(this.pictureBox1);
            this.panelResumenCompra.Controls.Add(this.labelTotal);
            this.panelResumenCompra.Controls.Add(this.label22);
            this.panelResumenCompra.Controls.Add(this.labelPrecio5);
            this.panelResumenCompra.Controls.Add(this.labelPrecio4);
            this.panelResumenCompra.Controls.Add(this.labelPrecio3);
            this.panelResumenCompra.Controls.Add(this.labelPrecio2);
            this.panelResumenCompra.Controls.Add(this.labelPrecio1);
            this.panelResumenCompra.Controls.Add(this.label16);
            this.panelResumenCompra.Controls.Add(this.labelDescuento5);
            this.panelResumenCompra.Controls.Add(this.labelDescuento4);
            this.panelResumenCompra.Controls.Add(this.labelDescuento3);
            this.panelResumenCompra.Controls.Add(this.labelDescuento2);
            this.panelResumenCompra.Controls.Add(this.label11);
            this.panelResumenCompra.Controls.Add(this.labelDescuento1);
            this.panelResumenCompra.Controls.Add(this.labelEntrada5);
            this.panelResumenCompra.Controls.Add(this.labelEntrada4);
            this.panelResumenCompra.Controls.Add(this.labelEntrada3);
            this.panelResumenCompra.Controls.Add(this.labelEntrada2);
            this.panelResumenCompra.Controls.Add(this.labelEntrada1);
            this.panelResumenCompra.Controls.Add(this.label3);
            this.panelResumenCompra.Controls.Add(this.pictureBox2);
            this.panelResumenCompra.Font = new System.Drawing.Font("Calibri Light", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelResumenCompra.Location = new System.Drawing.Point(29, 31);
            this.panelResumenCompra.Name = "panelResumenCompra";
            this.panelResumenCompra.Size = new System.Drawing.Size(1038, 682);
            this.panelResumenCompra.TabIndex = 17;
            this.panelResumenCompra.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri Light", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(160, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(284, 37);
            this.label3.TabIndex = 0;
            this.label3.Text = "Resumen de compra";
            // 
            // labelEntrada1
            // 
            this.labelEntrada1.AutoSize = true;
            this.labelEntrada1.Location = new System.Drawing.Point(227, 211);
            this.labelEntrada1.Name = "labelEntrada1";
            this.labelEntrada1.Size = new System.Drawing.Size(128, 33);
            this.labelEntrada1.TabIndex = 1;
            this.labelEntrada1.Text = "Entrada 1";
            // 
            // labelEntrada2
            // 
            this.labelEntrada2.AutoSize = true;
            this.labelEntrada2.Location = new System.Drawing.Point(227, 249);
            this.labelEntrada2.Name = "labelEntrada2";
            this.labelEntrada2.Size = new System.Drawing.Size(128, 33);
            this.labelEntrada2.TabIndex = 2;
            this.labelEntrada2.Text = "Entrada 2";
            // 
            // labelEntrada3
            // 
            this.labelEntrada3.AutoSize = true;
            this.labelEntrada3.Location = new System.Drawing.Point(227, 287);
            this.labelEntrada3.Name = "labelEntrada3";
            this.labelEntrada3.Size = new System.Drawing.Size(128, 33);
            this.labelEntrada3.TabIndex = 3;
            this.labelEntrada3.Text = "Entrada 3";
            // 
            // labelEntrada4
            // 
            this.labelEntrada4.AutoSize = true;
            this.labelEntrada4.Location = new System.Drawing.Point(227, 325);
            this.labelEntrada4.Name = "labelEntrada4";
            this.labelEntrada4.Size = new System.Drawing.Size(128, 33);
            this.labelEntrada4.TabIndex = 4;
            this.labelEntrada4.Text = "Entrada 4";
            // 
            // labelEntrada5
            // 
            this.labelEntrada5.AutoSize = true;
            this.labelEntrada5.Location = new System.Drawing.Point(227, 363);
            this.labelEntrada5.Name = "labelEntrada5";
            this.labelEntrada5.Size = new System.Drawing.Size(128, 33);
            this.labelEntrada5.TabIndex = 5;
            this.labelEntrada5.Text = "Entrada 5";
            // 
            // labelDescuento1
            // 
            this.labelDescuento1.Location = new System.Drawing.Point(430, 211);
            this.labelDescuento1.Name = "labelDescuento1";
            this.labelDescuento1.Size = new System.Drawing.Size(128, 33);
            this.labelDescuento1.TabIndex = 6;
            this.labelDescuento1.Text = " ";
            this.labelDescuento1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(385, 158);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(244, 33);
            this.label11.TabIndex = 7;
            this.label11.Text = "Descuento aplicado";
            // 
            // labelDescuento2
            // 
            this.labelDescuento2.Location = new System.Drawing.Point(430, 249);
            this.labelDescuento2.Name = "labelDescuento2";
            this.labelDescuento2.Size = new System.Drawing.Size(128, 33);
            this.labelDescuento2.TabIndex = 8;
            this.labelDescuento2.Text = " ";
            this.labelDescuento2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelDescuento3
            // 
            this.labelDescuento3.Location = new System.Drawing.Point(430, 287);
            this.labelDescuento3.Name = "labelDescuento3";
            this.labelDescuento3.Size = new System.Drawing.Size(128, 33);
            this.labelDescuento3.TabIndex = 9;
            this.labelDescuento3.Text = " ";
            this.labelDescuento3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelDescuento4
            // 
            this.labelDescuento4.Location = new System.Drawing.Point(430, 325);
            this.labelDescuento4.Name = "labelDescuento4";
            this.labelDescuento4.Size = new System.Drawing.Size(128, 33);
            this.labelDescuento4.TabIndex = 10;
            this.labelDescuento4.Text = " ";
            this.labelDescuento4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelDescuento5
            // 
            this.labelDescuento5.Location = new System.Drawing.Point(430, 363);
            this.labelDescuento5.Name = "labelDescuento5";
            this.labelDescuento5.Size = new System.Drawing.Size(128, 33);
            this.labelDescuento5.TabIndex = 11;
            this.labelDescuento5.Text = " ";
            this.labelDescuento5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(663, 158);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 33);
            this.label16.TabIndex = 12;
            this.label16.Text = "Precio";
            // 
            // labelPrecio5
            // 
            this.labelPrecio5.Location = new System.Drawing.Point(683, 363);
            this.labelPrecio5.Name = "labelPrecio5";
            this.labelPrecio5.Size = new System.Drawing.Size(128, 33);
            this.labelPrecio5.TabIndex = 17;
            this.labelPrecio5.Text = " ";
            this.labelPrecio5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelPrecio4
            // 
            this.labelPrecio4.Location = new System.Drawing.Point(683, 325);
            this.labelPrecio4.Name = "labelPrecio4";
            this.labelPrecio4.Size = new System.Drawing.Size(128, 33);
            this.labelPrecio4.TabIndex = 16;
            this.labelPrecio4.Text = " ";
            this.labelPrecio4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelPrecio3
            // 
            this.labelPrecio3.Location = new System.Drawing.Point(683, 287);
            this.labelPrecio3.Name = "labelPrecio3";
            this.labelPrecio3.Size = new System.Drawing.Size(128, 33);
            this.labelPrecio3.TabIndex = 15;
            this.labelPrecio3.Text = " ";
            this.labelPrecio3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelPrecio2
            // 
            this.labelPrecio2.Location = new System.Drawing.Point(683, 249);
            this.labelPrecio2.Name = "labelPrecio2";
            this.labelPrecio2.Size = new System.Drawing.Size(128, 33);
            this.labelPrecio2.TabIndex = 14;
            this.labelPrecio2.Text = " ";
            this.labelPrecio2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelPrecio1
            // 
            this.labelPrecio1.Location = new System.Drawing.Point(683, 211);
            this.labelPrecio1.Name = "labelPrecio1";
            this.labelPrecio1.Size = new System.Drawing.Size(128, 33);
            this.labelPrecio1.TabIndex = 13;
            this.labelPrecio1.Text = " ";
            this.labelPrecio1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(582, 483);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(86, 33);
            this.label22.TabIndex = 19;
            this.label22.Text = "TOTAL";
            // 
            // labelTotal
            // 
            this.labelTotal.Location = new System.Drawing.Point(683, 483);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(128, 33);
            this.labelTotal.TabIndex = 20;
            this.labelTotal.Text = " ";
            this.labelTotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::EntradasTeatro.Properties.Resources.business_ticket_2363;
            this.pictureBox2.Location = new System.Drawing.Point(233, 378);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(313, 269);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::EntradasTeatro.Properties.Resources.linea_horizontal;
            this.pictureBox1.Location = new System.Drawing.Point(569, 403);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::EntradasTeatro.Properties.Resources.business_ticket_2363;
            this.pictureBox3.Location = new System.Drawing.Point(0, 23);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(37, 37);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::EntradasTeatro.Properties.Resources.business_ticket_2363;
            this.pictureBox4.Location = new System.Drawing.Point(0, 23);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(37, 37);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 24;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::EntradasTeatro.Properties.Resources.business_ticket_2363;
            this.pictureBox5.Location = new System.Drawing.Point(0, 23);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(37, 37);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 25;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::EntradasTeatro.Properties.Resources.business_ticket_2363;
            this.pictureBox6.Location = new System.Drawing.Point(0, 23);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(37, 37);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 24;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::EntradasTeatro.Properties.Resources.business_ticket_2363;
            this.pictureBox7.Location = new System.Drawing.Point(0, 23);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(37, 37);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 24;
            this.pictureBox7.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1104, 746);
            this.Controls.Add(this.groupBoxEntrada4);
            this.Controls.Add(this.groupBoxEntrada1);
            this.Controls.Add(this.groupBoxEntrada2);
            this.Controls.Add(this.groupBoxEntrada3);
            this.Controls.Add(this.groupBoxEntrada5);
            this.Controls.Add(this.panelResumenCompra);
            this.Font = new System.Drawing.Font("Calibri Light", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.Name = "Form1";
            this.Text = "Compra de entradas de teatro";
            this.groupBoxEntrada1.ResumeLayout(false);
            this.groupBoxEntrada1.PerformLayout();
            this.groupBoxEntrada2.ResumeLayout(false);
            this.groupBoxEntrada2.PerformLayout();
            this.groupBoxEntrada3.ResumeLayout(false);
            this.groupBoxEntrada3.PerformLayout();
            this.groupBoxEntrada4.ResumeLayout(false);
            this.groupBoxEntrada4.PerformLayout();
            this.groupBoxEntrada5.ResumeLayout(false);
            this.groupBoxEntrada5.PerformLayout();
            this.panelResumenCompra.ResumeLayout(false);
            this.panelResumenCompra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAniadir1;
        private System.Windows.Forms.GroupBox groupBoxEntrada1;
        private System.Windows.Forms.RadioButton radioButton5E1;
        private System.Windows.Forms.RadioButton radioButton4E1;
        private System.Windows.Forms.RadioButton radioButton3E1;
        private System.Windows.Forms.RadioButton radioButton2E1;
        private System.Windows.Forms.RadioButton radioButton1E1;
        private System.Windows.Forms.Label labelEdad;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBoxEntrada2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.RadioButton radioButton5E2;
        private System.Windows.Forms.RadioButton radioButton4E2;
        private System.Windows.Forms.RadioButton radioButton3E2;
        private System.Windows.Forms.RadioButton radioButton2E2;
        private System.Windows.Forms.RadioButton radioButton1E2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxEntrada3;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.RadioButton radioButton5E3;
        private System.Windows.Forms.RadioButton radioButton4E3;
        private System.Windows.Forms.RadioButton radioButton3E3;
        private System.Windows.Forms.RadioButton radioButton2E3;
        private System.Windows.Forms.RadioButton radioButton1E3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxEntrada4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.RadioButton radioButton5E4;
        private System.Windows.Forms.RadioButton radioButton4E4;
        private System.Windows.Forms.RadioButton radioButton3E4;
        private System.Windows.Forms.RadioButton radioButton2E4;
        private System.Windows.Forms.RadioButton radioButton1E4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBoxEntrada5;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.RadioButton radioButton5E5;
        private System.Windows.Forms.RadioButton radioButton4E5;
        private System.Windows.Forms.RadioButton radioButton3E5;
        private System.Windows.Forms.RadioButton radioButton2E5;
        private System.Windows.Forms.RadioButton radioButton1E5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonCalcular1;
        private System.Windows.Forms.Button buttonCalcular2;
        private System.Windows.Forms.Button buttonAniadir2;
        private System.Windows.Forms.Button buttonCalcular3;
        private System.Windows.Forms.Button buttonAniadir3;
        private System.Windows.Forms.Button buttonCalcular4;
        private System.Windows.Forms.Button buttonAniadir4;
        private System.Windows.Forms.Button buttonCalcular5;
        private System.Windows.Forms.Panel panelResumenCompra;
        private System.Windows.Forms.Label labelEntrada1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelEntrada5;
        private System.Windows.Forms.Label labelEntrada4;
        private System.Windows.Forms.Label labelEntrada3;
        private System.Windows.Forms.Label labelEntrada2;
        private System.Windows.Forms.Label labelPrecio5;
        private System.Windows.Forms.Label labelPrecio4;
        private System.Windows.Forms.Label labelPrecio3;
        private System.Windows.Forms.Label labelPrecio2;
        private System.Windows.Forms.Label labelPrecio1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelDescuento5;
        private System.Windows.Forms.Label labelDescuento4;
        private System.Windows.Forms.Label labelDescuento3;
        private System.Windows.Forms.Label labelDescuento2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label labelDescuento1;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}

